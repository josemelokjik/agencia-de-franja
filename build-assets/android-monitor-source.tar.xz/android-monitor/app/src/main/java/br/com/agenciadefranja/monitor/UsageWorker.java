package br.com.agenciadefranja.monitor;

import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Polls OS usage events, filtering to previously chosen packages. No network requests. */
public final class UsageWorker extends Worker {
    private static final long DAY_MS = 86_400_000L;

    public UsageWorker(@NonNull Context context, @NonNull WorkerParameters parameters) {
        super(context, parameters);
    }

    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        AppPrefs prefs = new AppPrefs(context);
        if (!prefs.isActive()) return Result.success();
        // Never collect if the required access or visible status indication is unavailable.
        if (!UsagePermission.allowed(context) || !NotificationHelper.allowed(context)) {
            prefs.setActive(false);
            NotificationHelper.hide(context);
            return Result.success();
        }
        Set<String> packages = prefs.selectedPackages();
        if (packages.isEmpty()) return Result.success();

        long end = System.currentTimeMillis();
        long from = Math.max(prefs.lastScan(), end - 2 * DAY_MS);
        if (from <= 0L || from >= end) return Result.success();
        UsageStatsManager manager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (manager == null) return Result.retry();
        try {
            UsageEvents query = manager.queryEvents(from, end);
            if (query == null) return Result.retry(); // May occur while device is locked.
            UsageEvents.Event event = new UsageEvents.Event();
            List<EventRecord> kept = new ArrayList<>();
            while (query.hasNextEvent()) {
                query.getNextEvent(event);
                EventRecord accepted = EventFilter.accept(event.getPackageName(), event.getEventType(),
                        event.getTimeStamp(), packages, from, end);
                if (accepted != null) kept.add(accepted);
            }
            // A stop request may arrive while the query is being processed.
            if (!prefs.isActive()) return Result.success();
            NotificationHelper.show(context);
            try (LocalStore store = new LocalStore(context)) {
                store.save(kept, end - 7 * DAY_MS);
            }
            prefs.setLastScan(end);
            return Result.success();
        } catch (SecurityException | android.database.SQLException exception) {
            return Result.failure();
        }
    }
}

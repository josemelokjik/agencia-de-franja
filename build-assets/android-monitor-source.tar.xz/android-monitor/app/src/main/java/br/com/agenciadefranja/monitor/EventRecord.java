package br.com.agenciadefranja.monitor;

/** A minimal on-device app lifecycle event; never stores screen or content. */
public final class EventRecord {
    public final String packageName;
    public final String kind;
    public final long epochMillis;

    public EventRecord(String packageName, String kind, long epochMillis) {
        this.packageName = packageName;
        this.kind = kind;
        this.epochMillis = epochMillis;
    }
}

package br.com.agenciadefranja.monitor;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;

/** App-private SQLite, on-device only; unique key prevents duplicate polling records. */
final class LocalStore extends SQLiteOpenHelper {
    LocalStore(Context context) { super(context, "usage_events.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "package_name TEXT NOT NULL, kind TEXT NOT NULL, ts INTEGER NOT NULL, "
                + "UNIQUE(package_name,kind,ts))");
        db.execSQL("CREATE INDEX idx_events_ts ON events(ts)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        throw new IllegalStateException("Schema migration required");
    }

    void save(List<EventRecord> events, long retainAfter) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (EventRecord event : events) {
                ContentValues row = new ContentValues();
                row.put("package_name", event.packageName);
                row.put("kind", event.kind);
                row.put("ts", event.epochMillis);
                db.insertWithOnConflict("events", null, row, SQLiteDatabase.CONFLICT_IGNORE);
            }
            db.delete("events", "ts < ?", new String[]{String.valueOf(retainAfter)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    JSONArray lastEvents(int maxCount) throws JSONException {
        JSONArray rows = new JSONArray();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT package_name,kind,ts FROM events ORDER BY ts DESC LIMIT ?",
                new String[]{String.valueOf(maxCount)})) {
            while (cursor.moveToNext()) {
                JSONObject entry = new JSONObject();
                entry.put("package", cursor.getString(0));
                entry.put("event", cursor.getString(1));
                entry.put("timeEpochMs", cursor.getLong(2));
                rows.put(entry);
            }
        }
        return rows;
    }

    void clear() { getWritableDatabase().delete("events", null, null); }
}

package br.com.agenciadefranja.monitor;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Minimal, user-visible controls for voluntary, local app-usage reporting. */
public final class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 8;
    private static final int REQUEST_NOTIFICATIONS = 9;
    private TextView state;
    private AppPrefs prefs;

    private static final class ListedApp {
        final String name;
        final String packageName;
        ListedApp(String name, String packageName) {
            this.name = name;
            this.packageName = packageName;
        }
    }

    @Override public void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        prefs = new AppPrefs(this);

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        column.setPadding(pad, pad, pad, pad);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(column);
        setContentView(scroll);

        TextView header = new TextView(this);
        header.setText("Agência de Franja — Monitor de uso");
        header.setTextSize(20);
        column.addView(header);

        TextView disclosure = new TextView(this);
        disclosure.setPadding(0, pad / 2, 0, pad / 2);
        disclosure.setText("Este aplicativo registra somente horários e eventos de uso dos apps escolhidos. "
                + "Não grava tela, mensagens, teclado, áudio ou localização. "
                + "Os dados ficam neste aparelho. Monitoramento opcional, com aviso ativo e botão Parar.");
        column.addView(disclosure);

        state = new TextView(this);
        state.setPadding(0, pad / 2, 0, pad / 2);
        column.addView(state);
        addButton(column, "1 · Habilitar acesso às estatísticas", v -> startActivity(
                new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        addButton(column, "2 · Selecionar aplicativos", v -> chooseApps());
        addButton(column, "3 · Iniciar monitoramento", v -> beginWithDisclosure());
        addButton(column, "Parar monitoramento", v -> stopMonitoring());
        addButton(column, "Exportar relatório JSON", v -> exportReport());
        addButton(column, "Apagar registros locais", v -> confirmErase());
        refreshStatus();
    }

    private void addButton(LinearLayout container, String text, View.OnClickListener action) {
        Button button = new Button(this);
        button.setText(text);
        button.setOnClickListener(action);
        container.addView(button);
    }

    @Override protected void onResume() { super.onResume(); if (state != null) refreshStatus(); }

    private void refreshStatus() {
        state.setText("Situação: " + (prefs.isActive() ? "ATIVO" : "PARADO")
                + "\nAcesso a uso: " + (UsagePermission.allowed(this) ? "habilitado" : "pendente")
                + "\nAplicativos selecionados: " + prefs.selectedPackages().size()
                + "\nColeta: periódica (não em tempo real), somente local.");
    }

    private void chooseApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> launchers = pm.queryIntentActivities(query, 0);
        List<ListedApp> apps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo info : launchers) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            apps.add(new ListedApp(info.loadLabel(pm).toString(), pkg));
        }
        apps.sort(Comparator.comparing(app -> app.name.toLowerCase(java.util.Locale.ROOT)));
        if (apps.isEmpty()) {
            new AlertDialog.Builder(this).setMessage("Nenhum aplicativo compatível encontrado.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        Set<String> chosen = prefs.selectedPackages();
        String[] labels = new String[apps.size()];
        boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < apps.size(); i++) {
            ListedApp app = apps.get(i);
            labels[i] = app.name + " (" + app.packageName + ")";
            checked[i] = chosen.contains(app.packageName);
        }
        new AlertDialog.Builder(this)
                .setTitle("Aplicativos a registrar")
                .setMultiChoiceItems(labels, checked, (dialog, item, value) -> {
                    if (value) chosen.add(apps.get(item).packageName);
                    else chosen.remove(apps.get(item).packageName);
                })
                .setPositiveButton("Salvar seleção", (dialog, which) -> {
                    prefs.setSelectedPackages(chosen);
                    refreshStatus();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void beginWithDisclosure() {
        if (prefs.isActive()) { refreshStatus(); return; }
        if (!prefs.isInformed()) {
            new AlertDialog.Builder(this)
                    .setTitle("Ativar monitoramento local?")
                    .setMessage("Serão registrados somente eventos de uso dos aplicativos selecionados, "
                            + "com horário e identificador do aplicativo. Nada é enviado pela internet. "
                            + "Um aviso permanecerá ativo durante o monitoramento. "
                            + "Você pode parar ou apagar os dados a qualquer momento.")
                    .setPositiveButton("Entendi e ativar", (d, w) -> {
                        prefs.setInformed();
                        startMonitoring();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        startMonitoring();
    }

    private void startMonitoring() {
        if (prefs.selectedPackages().isEmpty()) {
            showMessage("Selecione pelo menos um aplicativo antes de iniciar.");
            return;
        }
        if (!UsagePermission.allowed(this)) {
            showMessage("Habilite manualmente o acesso às estatísticas de uso nas configurações do Android.");
            return;
        }
        if (!NotificationHelper.allowed(this)) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            } else {
                showMessage("Ative as notificações do aplicativo antes de iniciar.");
            }
            return;
        }
        prefs.setLastScan(System.currentTimeMillis()); // no collection of pre-activation history
        prefs.setActive(true);
        NotificationHelper.show(this);
        MonitorScheduler.start(this);
        refreshStatus();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_NOTIFICATIONS && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) startMonitoring();
        else if (requestCode == REQUEST_NOTIFICATIONS) showMessage("A indicação de atividade é necessária.");
    }

    private void stopMonitoring() {
        prefs.setActive(false);
        MonitorScheduler.stop(this);
        NotificationHelper.hide(this);
        refreshStatus();
    }

    private void exportReport() {
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("application/json");
        save.putExtra(Intent.EXTRA_TITLE, "agencia-de-franja-uso.json");
        startActivityForResult(save, REQUEST_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_EXPORT || resultCode != RESULT_OK || data == null) return;
        Uri destination = data.getData();
        if (destination == null) return;
        try (LocalStore store = new LocalStore(this);
             OutputStream stream = getContentResolver().openOutputStream(destination)) {
            if (stream == null) throw new IllegalStateException("Destino indisponível");
            JSONObject report = new JSONObject();
            report.put("schemaVersion", 1);
            report.put("generatedAt", Instant.now().toString());
            report.put("retentionDays", 7);
            report.put("selectedPackages", new JSONArray(prefs.selectedPackages()));
            report.put("events", store.lastEvents(5000));
            stream.write(report.toString(2).getBytes(StandardCharsets.UTF_8));
            showMessage("JSON exportado. Limite de 5.000 eventos mais recentes.");
        } catch (Exception exception) {
            showMessage("Falha ao exportar: " + exception.getClass().getSimpleName());
        }
    }

    private void confirmErase() {
        new AlertDialog.Builder(this)
                .setTitle("Apagar dados coletados?")
                .setMessage("Os registros locais serão excluídos. O monitoramento será interrompido.")
                .setPositiveButton("Apagar e parar", (dialog, which) -> {
                    stopMonitoring();
                    try (LocalStore store = new LocalStore(this)) { store.clear(); }
                    prefs.setLastScan(System.currentTimeMillis());
                    showMessage("Registros locais excluídos.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMessage(String message) {
        new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show();
    }
}

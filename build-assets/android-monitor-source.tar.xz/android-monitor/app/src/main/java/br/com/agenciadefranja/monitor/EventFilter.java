package br.com.agenciadefranja.monitor;

import java.util.Set;

/** Pure filter so only explicitly selected packages and basic lifecycle events are retained. */
public final class EventFilter {
    private EventFilter() {}

    public static EventRecord accept(String packageName, int eventType, long timestamp,
                                     Set<String> selected, long fromInclusive, long toExclusive) {
        if (packageName == null || selected == null || !selected.contains(packageName)
                || timestamp < fromInclusive || timestamp >= toExclusive) {
            return null;
        }
        final String kind;
        switch (eventType) {
            case 1: kind = "OPEN"; break;  // ACTIVITY_RESUMED
            case 2: kind = "PAUSE"; break; // ACTIVITY_PAUSED
            case 23: kind = "STOP"; break; // ACTIVITY_STOPPED
            default: return null;
        }
        return new EventRecord(packageName, kind, timestamp);
    }
}

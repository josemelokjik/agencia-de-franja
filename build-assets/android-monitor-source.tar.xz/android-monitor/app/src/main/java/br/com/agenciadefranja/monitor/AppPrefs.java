package br.com.agenciadefranja.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

final class AppPrefs {
    private static final String FILE = "monitor_settings";
    private final SharedPreferences prefs;

    AppPrefs(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    boolean isActive() { return prefs.getBoolean("active", false); }
    void setActive(boolean active) { prefs.edit().putBoolean("active", active).apply(); }
    boolean isInformed() { return prefs.getBoolean("informed", false); }
    void setInformed() { prefs.edit().putBoolean("informed", true).apply(); }

    Set<String> selectedPackages() {
        return new HashSet<>(prefs.getStringSet("selected_packages", new HashSet<>()));
    }
    void setSelectedPackages(Set<String> packages) {
        prefs.edit().putStringSet("selected_packages", new HashSet<>(packages)).apply();
    }

    long lastScan() { return prefs.getLong("last_scan", 0L); }
    void setLastScan(long timestamp) { prefs.edit().putLong("last_scan", timestamp).apply(); }
}

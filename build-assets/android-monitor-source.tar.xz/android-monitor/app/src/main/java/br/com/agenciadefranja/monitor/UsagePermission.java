package br.com.agenciadefranja.monitor;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Process;

final class UsagePermission {
    private UsagePermission() {}

    static boolean allowed(Context context) {
        AppOpsManager manager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        return manager != null && manager.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.getPackageName())
                == AppOpsManager.MODE_ALLOWED;
    }
}

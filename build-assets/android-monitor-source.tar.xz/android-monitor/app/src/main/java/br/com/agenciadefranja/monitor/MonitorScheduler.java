package br.com.agenciadefranja.monitor;

import android.content.Context;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

final class MonitorScheduler {
    private static final String UNIQUE = "selected_app_usage";
    private MonitorScheduler() {}

    static void start(Context context) {
        WorkManager manager = WorkManager.getInstance(context);
        PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(
                UsageWorker.class, 15, TimeUnit.MINUTES).build();
        manager.enqueueUniquePeriodicWork(UNIQUE, ExistingPeriodicWorkPolicy.UPDATE, periodic);
        manager.enqueue(new OneTimeWorkRequest.Builder(UsageWorker.class).build());
    }

    static void stop(Context context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE);
    }
}
